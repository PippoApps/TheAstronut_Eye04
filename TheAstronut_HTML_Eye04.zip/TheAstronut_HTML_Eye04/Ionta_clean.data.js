
var Module = typeof Module !== 'undefined' ? Module : {};

if (!Module.expectedDataFileDownloads) {
  Module.expectedDataFileDownloads = 0;
  Module.finishedDataFileDownloads = 0;
}
Module.expectedDataFileDownloads++;
(function() {
 var loadPackage = function(metadata) {

    var PACKAGE_PATH;
    if (typeof window === 'object') {
      PACKAGE_PATH = window['encodeURIComponent'](window.location.pathname.toString().substring(0, window.location.pathname.toString().lastIndexOf('/')) + '/');
    } else if (typeof location !== 'undefined') {
      // worker
      PACKAGE_PATH = encodeURIComponent(location.pathname.toString().substring(0, location.pathname.toString().lastIndexOf('/')) + '/');
    } else {
      throw 'using preloaded data can only be done on a web page or in a web worker';
    }
    var PACKAGE_NAME = 'C:/Users/linux/Documents/TheEye/TheAstronut_Eye04/Binaries/HTML5/Ionta_clean.data';
    var REMOTE_PACKAGE_BASE = 'Ionta_clean.data';
    if (typeof Module['locateFilePackage'] === 'function' && !Module['locateFile']) {
      Module['locateFile'] = Module['locateFilePackage'];
      err('warning: you defined Module.locateFilePackage, that has been renamed to Module.locateFile (using your locateFilePackage for now)');
    }
    var REMOTE_PACKAGE_NAME = Module['locateFile'] ? Module['locateFile'](REMOTE_PACKAGE_BASE, '') : REMOTE_PACKAGE_BASE;
  
    var REMOTE_PACKAGE_SIZE = metadata.remote_package_size;
    var PACKAGE_UUID = metadata.package_uuid;
  
    function fetchRemotePackage(packageName, packageSize, callback, errback) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', packageName, true);
      xhr.responseType = 'arraybuffer';
      xhr.onprogress = function(event) {
        var url = packageName;
        var size = packageSize;
        if (event.total) size = event.total;
        if (event.loaded) {
          if (!xhr.addedTotal) {
            xhr.addedTotal = true;
            if (!Module.dataFileDownloads) Module.dataFileDownloads = {};
            Module.dataFileDownloads[url] = {
              loaded: event.loaded,
              total: size
            };
          } else {
            Module.dataFileDownloads[url].loaded = event.loaded;
          }
          var total = 0;
          var loaded = 0;
          var num = 0;
          for (var download in Module.dataFileDownloads) {
          var data = Module.dataFileDownloads[download];
            total += data.total;
            loaded += data.loaded;
            num++;
          }
          total = Math.ceil(total * Module.expectedDataFileDownloads/num);
          if (Module['setStatus']) Module['setStatus']('Downloading data... (' + loaded + '/' + total + ')');
        } else if (!Module.dataFileDownloads) {
          if (Module['setStatus']) Module['setStatus']('Downloading data...');
        }
      };
      xhr.onerror = function(event) {
        throw new Error("NetworkError for: " + packageName);
      }
      xhr.onload = function(event) {
        if (xhr.status == 200 || xhr.status == 304 || xhr.status == 206 || (xhr.status == 0 && xhr.response)) { // file URLs can return 0
          var packageData = xhr.response;
          callback(packageData);
        } else {
          throw new Error(xhr.statusText + " : " + xhr.responseURL);
        }
      };
      xhr.send(null);
    };

    function handleError(error) {
      console.error('package error:', error);
    };
  
      var fetchedCallback = null;
      var fetched = Module['getPreloadedPackage'] ? Module['getPreloadedPackage'](REMOTE_PACKAGE_NAME, REMOTE_PACKAGE_SIZE) : null;

      if (!fetched) fetchRemotePackage(REMOTE_PACKAGE_NAME, REMOTE_PACKAGE_SIZE, function(data) {
        if (fetchedCallback) {
          fetchedCallback(data);
          fetchedCallback = null;
        } else {
          fetched = data;
        }
      }, handleError);
    
  function runWithFS() {

    function assert(check, msg) {
      if (!check) throw msg + new Error().stack;
    }
Module['FS_createPath']('/', 'Ionta_clean', true, true);
Module['FS_createPath']('/Ionta_clean', 'Content', true, true);
Module['FS_createPath']('/Ionta_clean/Content', 'Movies', true, true);
Module['FS_createPath']('/Ionta_clean/Content/Movies', 'Eye01', true, true);
Module['FS_createPath']('/Ionta_clean/Content', 'Paks', true, true);

    function DataRequest(start, end, audio) {
      this.start = start;
      this.end = end;
      this.audio = audio;
    }
    DataRequest.prototype = {
      requests: {},
      open: function(mode, name) {
        this.name = name;
        this.requests[name] = this;
        Module['addRunDependency']('fp ' + this.name);
      },
      send: function() {},
      onload: function() {
        var byteArray = this.byteArray.subarray(this.start, this.end);
        this.finish(byteArray);
      },
      finish: function(byteArray) {
        var that = this;

        Module['FS_createDataFile'](this.name, null, byteArray, true, true, true); // canOwn this data in the filesystem, it is a slide into the heap that will never change
        Module['removeRunDependency']('fp ' + that.name);

        this.requests[this.name] = null;
      }
    };

        var files = metadata.files;
        for (var i = 0; i < files.length; ++i) {
          new DataRequest(files[i].start, files[i].end, files[i].audio).open('GET', files[i].filename);
        }

  
    function processPackageData(arrayBuffer) {
      Module.finishedDataFileDownloads++;
      assert(arrayBuffer, 'Loading data file failed.');
      assert(arrayBuffer instanceof ArrayBuffer, 'bad input to processPackageData');
      var byteArray = new Uint8Array(arrayBuffer);
      var curr;
      
        // Reuse the bytearray from the XHR as the source for file reads.
        DataRequest.prototype.byteArray = byteArray;
  
          var files = metadata.files;
          for (var i = 0; i < files.length; ++i) {
            DataRequest.prototype.requests[files[i].filename].onload();
          }
              Module['removeRunDependency']('datafile_C:/Users/linux/Documents/TheEye/TheAstronut_Eye04/Binaries/HTML5/Ionta_clean.data');

    };
    Module['addRunDependency']('datafile_C:/Users/linux/Documents/TheEye/TheAstronut_Eye04/Binaries/HTML5/Ionta_clean.data');
  
    if (!Module.preloadResults) Module.preloadResults = {};
  
      Module.preloadResults[PACKAGE_NAME] = {fromCache: false};
      if (fetched) {
        processPackageData(fetched);
        fetched = null;
      } else {
        fetchedCallback = processPackageData;
      }
    
  }
  if (Module['calledRun']) {
    runWithFS();
  } else {
    if (!Module['preRun']) Module['preRun'] = [];
    Module["preRun"].push(runWithFS); // FS is not initialized yet, wait for it
  }

 }
 loadPackage({"files": [{"start": 0, "audio": 0, "end": 1985, "filename": "/Manifest_NonUFSFiles_HTML5.txt"}, {"start": 1985, "audio": 0, "end": 2027, "filename": "/UE4CommandLine.txt"}, {"start": 2027, "audio": 0, "end": 519318, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye00.png"}, {"start": 519318, "audio": 0, "end": 1033647, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye01.png"}, {"start": 1033647, "audio": 0, "end": 1548075, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye02.png"}, {"start": 1548075, "audio": 0, "end": 2063897, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye03.png"}, {"start": 2063897, "audio": 0, "end": 2654936, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye04.png"}, {"start": 2654936, "audio": 0, "end": 3084422, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye05.png"}, {"start": 3084422, "audio": 0, "end": 3529588, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye06.png"}, {"start": 3529588, "audio": 0, "end": 4008509, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye07.png"}, {"start": 4008509, "audio": 0, "end": 4166642, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye08.png"}, {"start": 4166642, "audio": 0, "end": 4321017, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye09.png"}, {"start": 4321017, "audio": 0, "end": 4593731, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye10.png"}, {"start": 4593731, "audio": 0, "end": 4886814, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye11.png"}, {"start": 4886814, "audio": 0, "end": 5089172, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye12.png"}, {"start": 5089172, "audio": 0, "end": 5314786, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye13.png"}, {"start": 5314786, "audio": 0, "end": 5543588, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye14.png"}, {"start": 5543588, "audio": 0, "end": 5774370, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye15.png"}, {"start": 5774370, "audio": 0, "end": 6007531, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye16.png"}, {"start": 6007531, "audio": 0, "end": 6248300, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye17.png"}, {"start": 6248300, "audio": 0, "end": 6535197, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye18.png"}, {"start": 6535197, "audio": 0, "end": 6811253, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye19.png"}, {"start": 6811253, "audio": 0, "end": 7066327, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye20.png"}, {"start": 7066327, "audio": 0, "end": 7256443, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye21.png"}, {"start": 7256443, "audio": 0, "end": 7401343, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye22.png"}, {"start": 7401343, "audio": 0, "end": 7552739, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye23.png"}, {"start": 7552739, "audio": 0, "end": 7711867, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye24.png"}, {"start": 7711867, "audio": 0, "end": 7874326, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye25.png"}, {"start": 7874326, "audio": 0, "end": 8352647, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye26.png"}, {"start": 8352647, "audio": 0, "end": 8386019, "filename": "/Ionta_clean/Content/Movies/Eye01/Eye27.png"}, {"start": 8386019, "audio": 0, "end": 156048537, "filename": "/Ionta_clean/Content/Paks/Ionta_clean-HTML5.pak"}], "remote_package_size": 156048537, "package_uuid": "776c618b-2976-47ac-8bc1-1a6a774d9413"});

})();
